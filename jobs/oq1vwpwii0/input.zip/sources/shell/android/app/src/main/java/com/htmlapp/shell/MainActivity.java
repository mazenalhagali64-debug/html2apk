package com.htmlapp.shell;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.*;
import android.widget.EditText;
import androidx.core.content.FileProvider;
import androidx.webkit.WebViewAssetLoader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends Activity {
    private static final String HOST = "appassets.androidplatform.net";
    private static final String HOME = "https://" + HOST + "/assets/www/index.html";
    private WebView web;
    private ValueCallback<Uri[]> fileCb;

    @Override protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        web = new WebView(this);
        setContentView(web);
        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .setDomain(HOST)
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);

        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return loader.shouldInterceptRequest(r.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                return !r.isForMainFrame() ? false : openOutside(r.getUrl());
            }
        });
        web.setDownloadListener((url, ua, cd, mime, len) -> openOutside(Uri.parse(url)));
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                try { startActivityForResult(p.createIntent(), 1); }
                catch (ActivityNotFoundException e) { fileCb = null; return false; }
                return true;
            }
            @Override public boolean onJsAlert(WebView v, String u, String m, JsResult r) {
                new AlertDialog.Builder(MainActivity.this).setMessage(m)
                        .setPositiveButton(android.R.string.ok, (d, i) -> r.confirm())
                        .setOnCancelListener(d -> r.cancel()).show();
                return true;
            }
            @Override public boolean onJsConfirm(WebView v, String u, String m, JsResult r) {
                new AlertDialog.Builder(MainActivity.this).setMessage(m)
                        .setPositiveButton(android.R.string.ok, (d, i) -> r.confirm())
                        .setNegativeButton(android.R.string.cancel, (d, i) -> r.cancel())
                        .setOnCancelListener(d -> r.cancel()).show();
                return true;
            }
            @Override public boolean onJsPrompt(WebView v, String u, String m, String def, JsPromptResult r) {
                final EditText in = new EditText(MainActivity.this);
                in.setText(def);
                new AlertDialog.Builder(MainActivity.this).setMessage(m).setView(in)
                        .setPositiveButton(android.R.string.ok, (d, i) -> r.confirm(in.getText().toString()))
                        .setNegativeButton(android.R.string.cancel, (d, i) -> r.cancel())
                        .setOnCancelListener(d -> r.cancel()).show();
                return true;
            }
        });
        try {
            getAssets().open("installer.flag").close();
            web.addJavascriptInterface(new Bridge(), "AndroidInstaller");
        } catch (Exception ignored) { }
        if (saved == null) web.loadUrl(HOME); else web.restoreState(saved);
    }

    private void toJs(final String s) {
        runOnUiThread(() -> web.evaluateJavascript("window.onInstall&&window.onInstall('" + s + "')", null));
    }

    private class Bridge {
        @JavascriptInterface
        public void installApk(final String apiUrl, final String token) {
            new Thread(() -> {
                try {
                    if (!apiUrl.startsWith("https://api.github.com/")) { toJs("error"); return; }
                    HttpURLConnection c = (HttpURLConnection) new URL(apiUrl).openConnection();
                    c.setInstanceFollowRedirects(false);
                    c.setRequestProperty("Authorization", "Bearer " + token);
                    c.setRequestProperty("Accept", "application/octet-stream");
                    c.setRequestProperty("User-Agent", "html2apk-app");
                    int code = c.getResponseCode();
                    String loc = c.getHeaderField("Location");
                    InputStream in;
                    if (code >= 300 && code < 400 && loc != null) {
                        c.disconnect();
                        c = (HttpURLConnection) new URL(loc).openConnection();
                    }
                    in = c.getInputStream();
                    File dir = new File(getCacheDir(), "apks");
                    dir.mkdirs();
                    final File f = new File(dir, "app.apk");
                    OutputStream o = new FileOutputStream(f);
                    byte[] buf = new byte[8192];
                    int n;
                    while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
                    o.close();
                    in.close();
                    runOnUiThread(() -> installFile(f));
                } catch (Exception e) {
                    toJs("error");
                }
            }).start();
        }
    }

    private void installFile(File f) {
        try {
            if (Build.VERSION.SDK_INT >= 26 && !getPackageManager().canRequestPackageInstalls()) {
                startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + getPackageName())));
                toJs("perm");
                return;
            }
            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".apkprovider", f);
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(uri, "application/vnd.android.package-archive");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
            toJs("ok");
        } catch (Exception e) {
            toJs("error");
        }
    }

    private boolean openOutside(Uri u) {
        if (HOST.equals(u.getHost())) return false;
        try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) { }
        return true;
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        if (req == 1 && fileCb != null) {
            fileCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
            fileCb = null;
        }
    }
    @Override protected void onSaveInstanceState(Bundle out) { super.onSaveInstanceState(out); web.saveState(out); }
    @Override protected void onPause() { super.onPause(); web.onPause(); }
    @Override protected void onResume() { super.onResume(); web.onResume(); }
    @Override public void onBackPressed() { if (web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
