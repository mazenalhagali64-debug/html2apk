import os, re, sys, shutil, zipfile
from xml.sax.saxutils import escape
from PIL import Image

job, ext = os.environ["JOB_ID"], os.environ["EXT"].lower()
if not re.fullmatch(r"[a-z][a-z0-9]{9}", job) or ext not in ("html", "htm", "zip"):
    sys.exit("bad input")
name = re.sub(r"[\x00-\x1f<>&\"'\\%@?]", "", os.environ.get("APP_NAME", "")).strip()[:40] or "تطبيقي"

app = "android/app/src/main"
www = f"{app}/assets/www"
shutil.rmtree(www, ignore_errors=True)
os.makedirs(www)
src = f"jobs/{job}/input.{ext}"

if ext != "zip":
    shutil.copy(src, f"{www}/index.html")
else:
    total = 0
    with zipfile.ZipFile(src) as z:
        if len(z.infolist()) > 3000:
            sys.exit("too many files")
        for i in z.infolist():
            p = os.path.normpath(i.filename)
            if i.is_dir() or p.startswith("/") or ".." in p.split(os.sep) or p.startswith("__MACOSX"):
                continue
            total += i.file_size
            if total > 150 * 1024 * 1024:
                sys.exit("too big")
            t = os.path.join(www, p)
            os.makedirs(os.path.dirname(t), exist_ok=True)
            with z.open(i) as s, open(t, "wb") as o:
                shutil.copyfileobj(s, o)
    idx = [r for r, _, fs in os.walk(www) if "index.html" in fs]
    if idx:
        root = min(idx, key=lambda r: r.count(os.sep))
    else:
        h = [(r, f) for r, _, fs in os.walk(www) for f in fs if f.lower().endswith((".html", ".htm"))]
        if not h:
            sys.exit("no html in zip")
        root, f = min(h, key=lambda x: x[0].count(os.sep))
        os.rename(os.path.join(root, f), os.path.join(root, "index.html"))
    if root != www:
        tmp = www + "_tmp"
        shutil.move(root, tmp)
        shutil.rmtree(www)
        shutil.move(tmp, www)

os.makedirs(f"{app}/res/values", exist_ok=True)
with open(f"{app}/res/values/strings.xml", "w", encoding="utf-8") as f:
    f.write(f'<?xml version="1.0" encoding="utf-8"?><resources><string name="app_name">{escape(name)}</string></resources>')

os.makedirs(f"{app}/res/drawable-nodpi", exist_ok=True)
try:
    im = Image.open(f"jobs/{job}/icon.png").convert("RGBA")
    s = min(im.size)
    l, t = (im.width - s) // 2, (im.height - s) // 2
    im = im.crop((l, t, l + s, t + s)).resize((432, 432))
except Exception:
    im = Image.new("RGBA", (432, 432), (11, 110, 95, 255))
im.save(f"{app}/res/drawable-nodpi/ic_launcher.png")
print("ready:", name)

html = open(f"{www}/index.html", encoding="utf-8", errors="ignore").read()
mf = f"{app}/AndroidManifest.xml"
man = open(mf, encoding="utf-8").read()
if 'name="installer"' in html:
    open(f"{app}/assets/installer.flag", "w").close()
    os.makedirs(f"{app}/res/xml", exist_ok=True)
    open(f"{app}/res/xml/file_paths.xml", "w").write('<?xml version="1.0" encoding="utf-8"?><paths><cache-path name="apks" path="apks/"/></paths>')
    man = man.replace("<!--PERM-->", '<uses-permission android:name="android.permission.REQUEST_INSTALL_PACKAGES" />')
    man = man.replace("<!--PROVIDER-->", '<provider android:name="androidx.core.content.FileProvider" android:authorities="${applicationId}.apkprovider" android:exported="false" android:grantUriPermissions="true"><meta-data android:name="android.support.FILE_PROVIDER_PATHS" android:resource="@xml/file_paths" /></provider>')
else:
    man = man.replace("<!--PERM-->", "").replace("<!--PROVIDER-->", "")
open(mf, "w", encoding="utf-8").write(man)
