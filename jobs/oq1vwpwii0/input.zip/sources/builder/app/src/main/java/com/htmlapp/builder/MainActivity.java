package com.htmlapp.builder;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.core.content.FileProvider;
import androidx.webkit.WebViewAssetLoader;
import com.android.apksig.ApkSigner;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.KeyFactory;
import java.security.MessageDigest;
import java.security.PrivateKey;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Enumeration;
import java.util.zip.CRC32;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

public class MainActivity extends Activity {
    private static final String HOST = "appassets.androidplatform.net";
    private WebView web;
    private ValueCallback<Uri[]> fileCb;

    @Override protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        web = new WebView(this);
        setContentView(web);
        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .setDomain(HOST)
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return loader.shouldInterceptRequest(r.getUrl());
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                try { startActivityForResult(p.createIntent(), 1); }
                catch (ActivityNotFoundException e) { fileCb = null; return false; }
                return true;
            }
        });
        web.addJavascriptInterface(new Bridge(), "AndroidBuilder");
        web.loadUrl("https://" + HOST + "/assets/www/index.html");
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        if (req == 1 && fileCb != null) {
            fileCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
            fileCb = null;
        }
    }

    @Override public void onBackPressed() { if (web.canGoBack()) web.goBack(); else super.onBackPressed(); }

    private void toJs(final String s) {
        runOnUiThread(() -> web.evaluateJavascript("window.onBuild&&window.onBuild('" + s + "')", null));
    }

    private static String clean(Throwable e) {
        String m = e.getClass().getSimpleName() + " " + e.getMessage();
        m = m.replaceAll("[^\\p{L}\\p{N} .:_/-]", " ");
        return m.length() > 160 ? m.substring(0, 160) : m;
    }

    private class Bridge {
        @JavascriptInterface
        public void build(final String b64, final String nameIn, final String iconB64, final String ext) {
            new Thread(() -> {
                try {
                    toJs("building");
                    byte[] html = Base64.decode(b64, Base64.DEFAULT);
                    File zipFile = null;
                    if ("zip".equalsIgnoreCase(ext)) {
                        zipFile = new File(getCacheDir(), "in.zip");
                        FileOutputStream zo0 = new FileOutputStream(zipFile);
                        zo0.write(html);
                        zo0.close();
                        html = null;
                    }
                    byte[] icon = (iconB64 == null || iconB64.isEmpty()) ? null : Base64.decode(iconB64, Base64.DEFAULT);
                    String name = fitName(nameIn);
                    File dir = new File(getCacheDir(), "apks");
                    dir.mkdirs();
                    File tpl = new File(getCacheDir(), "template.apk");
                    InputStream ti = getAssets().open("template.apk");
                    OutputStream to = new FileOutputStream(tpl);
                    pipe(ti, to);
                    File unsigned = new File(getCacheDir(), "unsigned.apk");
                    rewrite(tpl, unsigned, html, zipFile, name, icon);
                    if (zipFile != null) zipFile.delete();
                    final File out = new File(dir, "app.apk");
                    if (out.exists()) out.delete();
                    sign(unsigned, out);
                    runOnUiThread(() -> installFile(out));
                } catch (Throwable e) {
                    toJs("error:" + clean(e));
                }
            }).start();
        }
    }

    private static void pipe(InputStream in, OutputStream out) throws IOException {
        byte[] buf = new byte[16384];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        out.close();
        in.close();
    }

    private static byte[] readAll(InputStream in) throws IOException {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        pipe(in, bo);
        return bo.toByteArray();
    }

    private static class Counting extends FilterOutputStream {
        long count = 0;
        Counting(OutputStream o) { super(o); }
        @Override public void write(int b) throws IOException { out.write(b); count++; }
        @Override public void write(byte[] b, int off, int len) throws IOException { out.write(b, off, len); count += len; }
    }

    // Copy the template APK, replacing assets/www/index.html. resources.arsc stays STORED and 4-byte aligned.
    private static void rewrite(File src, File dst, byte[] index, File zipFile, String name, byte[] icon) throws Exception {
        ZipFile zf = new ZipFile(src);
        ZipFile site = zipFile != null ? new ZipFile(zipFile) : null;
        List<String[]> plan = site != null ? planZip(site) : null;
        String iconName = findIcon(zf);
        String pkg = pkgFor(name);
        Counting cos = new Counting(new BufferedOutputStream(new FileOutputStream(dst)));
        ZipOutputStream zo = new ZipOutputStream(cos);
        Enumeration<? extends ZipEntry> en = zf.entries();
        while (en.hasMoreElements()) {
            ZipEntry e = en.nextElement();
            String n = e.getName();
            if (e.isDirectory() || n.startsWith("META-INF/")) continue;
            if (plan != null && n.startsWith("assets/www/")) continue;
            byte[] data = readAll(zf.getInputStream(e));
            if (n.equals("assets/www/index.html")) data = index;
            else if (n.equals("AndroidManifest.xml")) data = patchPkg(data, pkg);
            else if (n.equals("resources.arsc")) data = patchLabel(patchPkg(data, pkg), name);
            else if (icon != null && n.equals(iconName)) data = icon;
            ZipEntry ne = new ZipEntry(n);
            if (n.equals("resources.arsc")) {
                ne.setMethod(ZipEntry.STORED);
                ne.setSize(data.length);
                ne.setCompressedSize(data.length);
                CRC32 crc = new CRC32();
                crc.update(data);
                ne.setCrc(crc.getValue());
                long base = cos.count + 30 + n.getBytes("UTF-8").length;
                int pad = (int) ((4 - base % 4) % 4);
                if (pad != 0) {
                    int len = pad + 4;
                    byte[] x = new byte[len];
                    x[0] = 0x35; x[1] = (byte) 0xD9; x[2] = (byte) (len - 4); x[3] = 0;
                    ne.setExtra(x);
                }
            } else {
                ne.setMethod(ZipEntry.DEFLATED);
            }
            zo.putNextEntry(ne);
            zo.write(data);
            zo.closeEntry();
        }
        if (plan != null) {
            HashSet<String> seen = new HashSet<String>();
            for (String[] pr : plan) {
                if (!seen.add(pr[1])) continue;
                ZipEntry ne = new ZipEntry(pr[1]);
                ne.setMethod(ZipEntry.DEFLATED);
                zo.putNextEntry(ne);
                InputStream in = site.getInputStream(site.getEntry(pr[0]));
                byte[] buf = new byte[16384];
                int k;
                while ((k = in.read(buf)) > 0) zo.write(buf, 0, k);
                in.close();
                zo.closeEntry();
            }
            site.close();
        }
        zo.close();
        zf.close();
    }

    // Which files of the uploaded ZIP go to assets/www/, and under what name. Same rules as the online builder:
    // the shallowest index.html decides the root folder; if there is none, the shallowest .html is renamed index.html.
    private static List<String[]> planZip(ZipFile z) throws IOException {
        List<String[]> files = new ArrayList<String[]>();
        long total = 0;
        Enumeration<? extends ZipEntry> en = z.entries();
        while (en.hasMoreElements()) {
            ZipEntry e = en.nextElement();
            if (e.isDirectory()) continue;
            String p = e.getName().replace('\\', '/');
            while (p.startsWith("/")) p = p.substring(1);
            if (p.isEmpty() || p.startsWith("__MACOSX/") || p.endsWith(".DS_Store")) continue;
            boolean bad = false;
            for (String part : p.split("/")) if (part.equals("..")) bad = true;
            if (bad) continue;
            if (files.size() >= 3000) throw new IOException("too many files");
            total += Math.max(0, e.getSize());
            if (total > 150L * 1024 * 1024) throw new IOException("zip too big");
            files.add(new String[]{e.getName(), p});
        }
        int bestDepth = Integer.MAX_VALUE;
        String root = null, renamed = null;
        for (String[] f : files) {
            String p = f[1];
            if (!(p.equals("index.html") || p.endsWith("/index.html"))) continue;
            int d = p.split("/").length;
            if (d < bestDepth) { bestDepth = d; root = p.substring(0, p.length() - "index.html".length()); }
        }
        if (root == null) {
            for (String[] f : files) {
                String lp = f[1].toLowerCase();
                if (!(lp.endsWith(".html") || lp.endsWith(".htm"))) continue;
                int d = f[1].split("/").length;
                if (d < bestDepth) { bestDepth = d; root = f[1].substring(0, f[1].lastIndexOf('/') + 1); renamed = f[1]; }
            }
        }
        if (root == null) throw new IOException("no html in zip");
        List<String[]> out = new ArrayList<String[]>();
        for (String[] f : files) {
            if (!f[1].startsWith(root)) continue;
            String rel = f[1].substring(root.length());
            if (renamed != null && f[1].equals(renamed)) rel = "index.html";
            out.add(new String[]{f[0], "assets/www/" + rel});
        }
        return out;
    }


    // ---- name / package / icon patching (all in place, no change of file sizes) ----
    private static final String PH_NAME = "APPNAMEPLACEHOLDERXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    private static final String PH_PKG = "com.htmlapp.zzzzzzzzzzzz";

    private static String fitName(String in) {
        String n = in == null ? "" : in.replaceAll("[\\p{Cc}<>&\"'\\\\%@?]", "").trim();
        if (n.isEmpty()) n = "\u062a\u0637\u0628\u064a\u0642\u064a";
        try {
            while (n.getBytes("UTF-8").length > PH_NAME.length()) n = n.substring(0, n.length() - 1);
        } catch (Exception ignored) { }
        return n;
    }

    // Same name -> same package, so rebuilding an app with the same name updates it instead of duplicating it.
    private static String pkgFor(String name) throws Exception {
        byte[] h = MessageDigest.getInstance("SHA-256").digest(name.getBytes("UTF-8"));
        String al = "abcdefghijklmnopqrstuvwxyz0123456789";
        StringBuilder sb = new StringBuilder("com.htmlapp.");
        sb.append((char) ('a' + (h[0] & 0xff) % 26));
        for (int k = 1; k < 12; k++) sb.append(al.charAt((h[k] & 0xff) % 36));
        return sb.toString();
    }

    private static int indexOf(byte[] d, byte[] p, int from) {
        outer:
        for (int i = from; i <= d.length - p.length; i++) {
            for (int j = 0; j < p.length; j++) if (d[i + j] != p[j]) continue outer;
            return i;
        }
        return -1;
    }

    private static void replaceAll(byte[] d, byte[] from, byte[] to) {
        int i = 0;
        while ((i = indexOf(d, from, i)) >= 0) {
            System.arraycopy(to, 0, d, i, to.length);
            i += to.length;
        }
    }

    private static byte[] patchPkg(byte[] d, String pkg) throws IOException {
        replaceAll(d, PH_PKG.getBytes("US-ASCII"), pkg.getBytes("US-ASCII"));
        replaceAll(d, PH_PKG.getBytes("UTF-16LE"), pkg.getBytes("UTF-16LE"));
        return d;
    }

    private static byte[] patchLabel(byte[] d, String name) throws IOException {
        int cap = PH_NAME.length();
        int i = indexOf(d, PH_NAME.getBytes("US-ASCII"), 0);
        if (i >= 2 && (d[i - 1] & 0xff) == cap && (d[i - 2] & 0xff) == cap) {          // UTF-8 string pool
            byte[] nb = name.getBytes("UTF-8");
            d[i - 2] = (byte) name.length();
            d[i - 1] = (byte) nb.length;
            java.util.Arrays.fill(d, i, i + cap + 1, (byte) 0);
            System.arraycopy(nb, 0, d, i, nb.length);
            return d;
        }
        i = indexOf(d, PH_NAME.getBytes("UTF-16LE"), 0);
        if (i >= 2 && (d[i - 2] & 0xff) == cap && d[i - 1] == 0) {                     // UTF-16 string pool
            byte[] nb = name.getBytes("UTF-16LE");
            d[i - 2] = (byte) name.length();
            d[i - 1] = 0;
            java.util.Arrays.fill(d, i, i + cap * 2 + 2, (byte) 0);
            System.arraycopy(nb, 0, d, i, nb.length);
            return d;
        }
        throw new IOException("label placeholder not found");
    }

    private static String findIcon(ZipFile zf) {
        String named = null, only = null;
        int count = 0;
        Enumeration<? extends ZipEntry> en = zf.entries();
        while (en.hasMoreElements()) {
            String n = en.nextElement().getName();
            if (n.startsWith("res/") && n.endsWith(".png")) {
                count++;
                only = n;
                if (n.contains("ic_launcher")) named = n;
            }
        }
        return named != null ? named : (count == 1 ? only : null);
    }

    private void sign(File in, File out) throws Exception {
        byte[] kb = readAll(getAssets().open("key.pk8"));
        byte[] cb = readAll(getAssets().open("cert.der"));
        PrivateKey pk = KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(kb));
        X509Certificate cert = (X509Certificate) CertificateFactory.getInstance("X.509")
                .generateCertificate(new ByteArrayInputStream(cb));
        ApkSigner.SignerConfig sc = new ApkSigner.SignerConfig.Builder("html", pk, Collections.singletonList(cert)).build();
        new ApkSigner.Builder(Collections.singletonList(sc))
                .setInputApk(in)
                .setOutputApk(out)
                .setV1SigningEnabled(true)
                .setV2SigningEnabled(true)
                .setV3SigningEnabled(false)
                .setMinSdkVersion(23)
                .build()
                .sign();
    }

    private void installFile(File f) {
        try {
            if (Build.VERSION.SDK_INT >= 26 && !getPackageManager().canRequestPackageInstalls()) {
                startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + getPackageName())));
                toJs("perm");
                return;
            }
            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".apkprovider", f);
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(uri, "application/vnd.android.package-archive");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
            toJs("ok");
        } catch (Exception e) {
            toJs("error:" + clean(e));
        }
    }
}
