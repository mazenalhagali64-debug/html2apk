# استوديو برو — بناء APK
المتطلبات: Node 18+، Android Studio، JDK 17.
1. npm install
2. npx cap add android
3. npx cap sync android
4. npx cap open android   (ثم Build > Build APK)
   أو من الطرفية: cd android && ./gradlew assembleDebug
   الملف الناتج: android/app/build/outputs/apk/debug/app-debug.apk
ملاحظات: رفع الدقة وإزالة الخلفية خوارزميات تعمل أوفلاين داخل التطبيق (ليست نماذج AI ثقيلة).
لاستبدالها بنموذج حقيقي (Real-ESRGAN / U2-Net) ضع ملف ONNX في www/models واستخدم onnxruntime-web.
