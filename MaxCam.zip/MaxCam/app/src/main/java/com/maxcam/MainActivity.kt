package com.maxcam

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.ImageFormat
import android.graphics.SurfaceTexture
import android.hardware.camera2.*
import android.hardware.camera2.params.OutputConfiguration
import android.hardware.camera2.params.SessionConfiguration
import android.media.ImageReader
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.provider.MediaStore
import android.util.Size
import android.view.Gravity
import android.view.Surface
import android.view.TextureView
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import java.util.concurrent.Executor

class MainActivity : Activity() {
    private lateinit var tv: TextureView
    private lateinit var info: TextView
    private lateinit var toggle: Button
    private lateinit var shutter: Button

    private val thread = HandlerThread("cam").also { it.start() }
    private val handler = Handler(thread.looper)
    private val exec = Executor { handler.post(it) }

    private var device: CameraDevice? = null
    private var session: CameraCaptureSession? = null
    private var reader: ImageReader? = null
    private var previewSurface: Surface? = null
    private var camId = ""
    private var chars: CameraCharacteristics? = null
    private var normalSize = Size(4000, 3000)
    private var maxSize: Size? = null
    private var useMax = false

    private fun Size.area() = width.toLong() * height

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val w = resources.displayMetrics.widthPixels
        val root = FrameLayout(this).apply { setBackgroundColor(0xFF000000.toInt()) }
        tv = TextureView(this)
        root.addView(tv, FrameLayout.LayoutParams(w, w * 4 / 3, Gravity.TOP))

        info = TextView(this).apply { setTextColor(-1); textSize = 16f; gravity = Gravity.CENTER }
        toggle = Button(this)
        shutter = Button(this).apply { text = "📷 التقاط" }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(24, 24, 24, 48)
            addView(info)
            addView(toggle)
            addView(shutter)
        }
        root.addView(
            bar,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM)
        )
        setContentView(root)

        toggle.setOnClickListener { useMax = !useMax; startSession() }
        shutter.setOnClickListener { shoot() }
        tv.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(s: SurfaceTexture, w: Int, h: Int) { openCam() }
            override fun onSurfaceTextureSizeChanged(s: SurfaceTexture, w: Int, h: Int) {}
            override fun onSurfaceTextureDestroyed(s: SurfaceTexture) = true
            override fun onSurfaceTextureUpdated(s: SurfaceTexture) {}
        }
    }

    override fun onResume() { super.onResume(); if (tv.isAvailable) openCam() }

    override fun onPause() {
        session?.close(); session = null
        device?.close(); device = null
        reader?.close(); reader = null
        super.onPause()
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, g: IntArray) {
        super.onRequestPermissionsResult(rc, p, g)
        if (g.isNotEmpty() && g[0] == PackageManager.PERMISSION_GRANTED && tv.isAvailable) openCam()
    }

    // اختيار الكاميرا الخلفية ذات أكبر عدد بكسلات
    private fun pick(): Boolean {
        val m = getSystemService(CAMERA_SERVICE) as CameraManager
        var best = 0L
        for (id in m.cameraIdList) {
            val c = m.getCameraCharacteristics(id)
            if (c.get(CameraCharacteristics.LENS_FACING) != CameraCharacteristics.LENS_FACING_BACK) continue
            val n = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
                ?.getOutputSizes(ImageFormat.JPEG)?.maxByOrNull { it.area() } ?: continue
            var x = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP_MAXIMUM_RESOLUTION)
                ?.getOutputSizes(ImageFormat.JPEG)?.maxByOrNull { it.area() }
            if (x != null && x.area() <= n.area()) x = null
            val top = maxOf(n.area(), x?.area() ?: 0L)
            if (top > best) { best = top; camId = id; chars = c; normalSize = n; maxSize = x }
        }
        return best > 0
    }

    @SuppressLint("MissingPermission")
    private fun openCam() {
        if (device != null) return
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.CAMERA), 1); return
        }
        if (!pick()) { ui("لا توجد كاميرا خلفية"); return }
        useMax = maxSize != null
        val m = getSystemService(CAMERA_SERVICE) as CameraManager
        m.openCamera(camId, object : CameraDevice.StateCallback() {
            override fun onOpened(d: CameraDevice) { device = d; startSession() }
            override fun onDisconnected(d: CameraDevice) { d.close(); device = null }
            override fun onError(d: CameraDevice, e: Int) { d.close(); device = null }
        }, handler)
    }

    private fun startSession() {
        val d = device ?: return
        session?.close(); session = null
        val cap = if (useMax) maxSize ?: normalSize else normalSize
        val map = chars!!.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)!!
        val sizes = map.getOutputSizes(SurfaceTexture::class.java)
        val ps = sizes.filter { it.width <= 1920 && Math.abs(it.width.toFloat() / it.height - 4f / 3f) < 0.03f }
            .maxByOrNull { it.area() } ?: sizes.first()
        val st = tv.surfaceTexture ?: return
        st.setDefaultBufferSize(ps.width, ps.height)
        previewSurface = Surface(st)

        reader?.close()
        reader = ImageReader.newInstance(cap.width, cap.height, ImageFormat.JPEG, 2).also {
            it.setOnImageAvailableListener({ r -> save(r) }, handler)
        }

        val jc = OutputConfiguration(reader!!.surface)
        if (useMax && maxSize != null) {
            jc.addSensorPixelModeUsed(CameraMetadata.SENSOR_PIXEL_MODE_MAXIMUM_RESOLUTION)
        }
        val cfg = SessionConfiguration(
            SessionConfiguration.SESSION_REGULAR,
            listOf(OutputConfiguration(previewSurface!!), jc),
            exec,
            object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(s: CameraCaptureSession) { session = s; preview(); refreshUi() }
                override fun onConfigureFailed(s: CameraCaptureSession) {
                    if (useMax) {
                        useMax = false; maxSize = null
                        ui("الدقة القصوى مرفوضة من النظام، رجعنا للوضع العادي")
                        startSession()
                    } else ui("فشل فتح الكاميرا")
                }
            }
        )
        d.createCaptureSession(cfg)
    }

    private fun preview() {
        val d = device ?: return
        val s = session ?: return
        val b = d.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
        b.addTarget(previewSurface!!)
        b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
        s.setRepeatingRequest(b.build(), null, handler)
    }

    private fun shoot() {
        val d = device ?: return
        val s = session ?: return
        val b = d.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE)
        b.addTarget(reader!!.surface)
        b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
        b.set(CaptureRequest.JPEG_QUALITY, 100.toByte())
        b.set(CaptureRequest.JPEG_ORIENTATION, chars!!.get(CameraCharacteristics.SENSOR_ORIENTATION)!!)
        if (useMax && maxSize != null) {
            b.set(CaptureRequest.SENSOR_PIXEL_MODE, CameraMetadata.SENSOR_PIXEL_MODE_MAXIMUM_RESOLUTION)
        }
        ui("جاري الالتقاط…")
        s.stopRepeating()
        s.capture(b.build(), object : CameraCaptureSession.CaptureCallback() {
            override fun onCaptureCompleted(
                s: CameraCaptureSession, r: CaptureRequest, res: TotalCaptureResult
            ) { preview() }

            override fun onCaptureFailed(s: CameraCaptureSession, r: CaptureRequest, f: CaptureFailure) {
                ui("فشل الالتقاط"); preview()
            }
        }, handler)
    }

    private fun save(r: ImageReader) {
        val img = r.acquireLatestImage() ?: return
        val buf = img.planes[0].buffer
        val bytes = ByteArray(buf.remaining())
        buf.get(bytes)
        val w = img.width
        val h = img.height
        img.close()
        val v = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "MaxCam_${System.currentTimeMillis()}.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/MaxCam")
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v) ?: return
        contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
        v.clear()
        v.put(MediaStore.Images.Media.IS_PENDING, 0)
        contentResolver.update(uri, v, null, null)
        ui("تم الحفظ: ${w}×${h} ≈ ${"%.1f".format(w.toLong() * h / 1e6)} MP")
    }

    private fun ui(s: String) = runOnUiThread { info.text = s }

    private fun refreshUi() = runOnUiThread {
        val cap = if (useMax) maxSize ?: normalSize else normalSize
        info.text = "${cap.width}×${cap.height} ≈ ${"%.1f".format(cap.area() / 1e6)} MP"
        toggle.isEnabled = maxSize != null
        toggle.text = when {
            maxSize == null -> "الدقة القصوى: غير متاحة"
            useMax -> "الدقة القصوى: مفعّلة"
            else -> "الدقة القصوى: متوقفة"
        }
    }
}
